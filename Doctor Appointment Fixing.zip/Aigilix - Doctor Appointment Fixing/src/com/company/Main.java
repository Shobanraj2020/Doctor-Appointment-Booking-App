package com.company;

import java.util.*;

public class Main {



    public static void Booking_detail(String Booking){
        //System.out.println(Booking);
        String details[]=Booking.split(",");
        System.out.print("     ********* APPOINTMENT DETAILS *********");
        //System.out.print("     ********* APPOINTMENT DETAILS *********");
        System.out.print("\n     Name of the patient = "+details[0]);
        System.out.print("\n     Age of the patient = "+details[1]);
        System.out.print("\n     Mobile Number = "+details[2]);
        System.out.print("\n     Specialist  = "+details[3]);
        System.out.print("\n     Doctor's Name = "+details[4]);
        System.out.print("\n     Timing slot = "+details[5]);
        return;

    }

    public static void main(String[] args) {
	// write your code here
        System.out.println("\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tDOCTOR APPOINTMENT BOOKING ");
        Scanner input = new Scanner(System.in);
        String Timing[]={"8.30 AM","10.30 AM","4.30 PM","7.00 PM"};
        Customer_details Customer=new Customer_details();

        List<String> list1 = new ArrayList<>(Arrays.asList(Timing));
        List<String> list2 = new ArrayList<>(Arrays.asList(Timing));
        List<String> list3 = new ArrayList<>(Arrays.asList(Timing));
        List<String> list4 = new ArrayList<>(Arrays.asList(Timing));
        String Booking_details[]=new String[16];
        boolean done=false;
        int i=0,count=0;

        while(done==false) {
            System.out.print("\n\nPress 1 To Book an Appointment ");
            System.out.print("\n\nPress 2 To Revisit your Appointment details");
            //System.out.print("\n\nSelect your Choice = ");
            int function = 0;
            boolean sucess0=false;
            while(!sucess0){
                try{
                    System.out.print("\n\nSelect your Choice = ");
                    function= input.nextInt();
                    sucess0=true;

                }catch (InputMismatchException e){
                    input.next();
                    System.out.println("Please enter a valid Number");
                }
            }


            i=count;


            if(function==1) {

                for (i =count; i < Booking_details.length; i++) {


                    boolean sucess1 = false;
                    int Age = 0;
                    String age = "";

                    while (!sucess1) {
                        try {
                            System.out.print("\n\nEnter the age of the patient = ");
                            Age = input.nextInt();
                            age = String.valueOf(Age);
                            if (age.length() <= 2 && Age != 0 &&!age.contains("-") ) {
                                sucess1 = true;
                            } else {
                                System.out.println("--Entered an invalid data--Please enter a valid AGE to proceed with the Registration");

                            }

                        } catch (InputMismatchException e) {
                            input.next();
                            System.out.println("--Entered a invalid data--Please enter a valid AGE to Proceed with the Registration");
                        }
                    }


                    input.nextLine();


                    sucess1 = false;
                    String Name_of_patient = "";
                    while (!sucess1) {
                        System.out.print("\n\nName of the Patient : ");
                        Name_of_patient = input.nextLine();
                        if (Name_of_patient.matches("^[a-zA-Z ]*$")) {
                            sucess1 = true;
                        } else {
                            System.out.println("----Please enter a valid Name with only Alphabets [A-Z] ");
                        }

                    }

                    Booking_details[i] = Name_of_patient;


                    Booking_details[i] += "," + String.valueOf(Age);


                    long mobile=0;
                    sucess1=false;
                    while(!sucess1){
                        try{
                            System.out.print("\n\nENTER YOUR CONTACT NUMBER = ");
                            mobile=input.nextLong();
                            String mob_len=String.valueOf(mobile);
                            int length=mob_len.length();
                            if(mobile!=0&&length==10&&!mob_len.contains("-")){
                                sucess1=true;
                            }else{
                                System.out.println("--Enter a valid Mobile number" );
                            }

                        }catch (InputMismatchException e){
                            input.next();
                            System.out.println("Enter a valid Mobile number --- Which used for Re-visiting your Appointment Details" );
                        }
                    }

                    Booking_details[i]+=","+String.valueOf(mobile);

                    System.out.println("\n\nPRESS the Required number to Consult the Specialist = ");

                    System.out.println("PRESS 1 FOR NUTRITIONIST");
                    System.out.println("PRESS 2 FOR CARDIOLOGIST");
                    System.out.println("PRESS 3 FOR DIABETOLOGIST");
                    System.out.println("PRESS 4 FOR HEPATOLOGIST");


                    int Type = 0;
                    sucess1 = false;

                    while (!sucess1) {
                        try {
                            System.out.print("\nEnter the Number = ");
                            Type = input.nextInt();
                            if (Type == 1 || Type == 2|| Type == 3 || Type==4) {
                                sucess1 = true;
                            } else {
                                System.out.println("--Entered a invalid data--Please enter a valid TYPE to Proceed with the Registration");

                            }
                        } catch (InputMismatchException e) {
                            input.next();
                            System.out.println("--Entered a invalid data--Please enter a valid TYPE to Proceed with the Registration");
                            ;
                        }


                    }

                    if (Type == 1) {
                        if (list1.size() == 0) {
                            System.out.println("The slots for Nutritionist are Not available Kindly check back Tomorrow!");
                            Booking_details[i] = null;

                        }

                    }
                    if (Type == 2) {
                        if (list2.size() == 0) {
                            System.out.println("The slots for Cardiologist are Not available Kindly check back Tomorrow!");
                            Booking_details[i] = null;

                        }
                    }
                    if(Type==3){
                        if(list3.size()==0){
                            System.out.println("The slots for Diabetologist are Not available Kindly check back Tomorrow!");
                            Booking_details[i]=null;

                        }
                    }
                    if(Type==4){
                        if(list4.size()==0){
                            System.out.println("The slots for Hepatologist are Not available Kindly check back Tomorrow!");

                        }
                    }

                    if (Booking_details[i] != null) {


                        String Speciality[] = {"Nutritionist", "Cardiologist","Diabetologist","Hepatologist"};
                        Booking_details[i] += "," + Speciality[Type - 1];
                        Nutritionist obj1 = new Nutritionist();
                        Cardiologist obj2 = new Cardiologist();
                        Diabetologist obj3= new Diabetologist();
                        Hepatologist obj4=new Hepatologist();


                        //System.out.println("\n\n" + list1);

                        switch (Type) {
                            case 1: {
                                Booking_details[i] += "," + "Dr.Balamurugan";
                                obj1.Balamurugan(Booking_details, list1, i);
                            }
                            break;
                            case 2: {
                                Booking_details[i] += "," + "Dr.Sankara Narayanan";
                                obj2.SankaraNarayanan(Booking_details, list2, i);
                            }
                            break;
                            case 3:{
                                Booking_details[i]+=","+"Dr.Venu Gopal";
                                obj3.VenuGopal(Booking_details,list3,i);

                            }
                            break;
                            case 4:{
                                Booking_details[i]+=","+"Dr.Rela";
                                obj4.Rela(Booking_details,list4,i);
                            }
                            break;

                        }


                        //System.out.println("\nBooking details = " + Booking_details[i]);
                        String Booking = Booking_details[i];

                        System.out.println("\n\n");
                        Booking_detail(Booking);

                        if (Type == 1) {
                            System.out.println("\nRemaining time slot of Dr.Balamurugan (NUTRITIONIST) = " + list1);
                        }
                        if (Type == 2) {
                            System.out.print("\nRemaining time slot of Dr.SankaraNarayanan (CARDIOLOGIST) = " + list2);
                        }
                        if(Type==3){
                            System.out.print("\nRemaining time slot of Dr.VenuGopal (DIABETOLOGIST) = " + list3);
                        }
                        if(Type==4){
                            System.out.print("\nRemaining time slot of Dr.Rela (HEPATOLOGIST) = " + list4);
                        }
                        count++;

                    } else if (Booking_details[i] == null) {

                    }
                    break;

                }
            }else if(function==2){
                //System.out.println(Arrays.toString(Booking_details));
                if(Booking_details[0]==null){
                    System.out.println("No slots have been booked to view");

                }else if(Booking_details!=null){

                    System.out.println("Enter your Mobile Number to Re-visit your booking details = ");
                    long Mobile=input.nextLong();
                    Customer.details(Mobile,Booking_details);

                }

            }else {
                System.out.println("---Please enter a valid Number");
            }
            if(count== Booking_details.length){
                done=true;
            }

        }
        boolean Start=false;

        while(!Start){
            System.out.print("\n\nAll slots are Full and No doctor is available today");
            System.out.print("\n\nBooked patients can view their Appointment details by Entering the Mobile Number");
            System.out.print("\n\nEnter your Mobile Number = ");
            long Phone= input.nextLong();
            Customer.details(Phone,Booking_details);
            System.out.print("\n\nPress 0 to End & Start Booking for Next Day = ");
            int start= input.nextInt();
            if(start==0){
               Start=true;
            }

        }





         }


}
