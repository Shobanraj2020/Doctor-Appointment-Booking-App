package com.company;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Hepatologist {
    Scanner input5=new Scanner(System.in);
    public void Rela(String Booking[], List<String> list4, int m){
        boolean sucess4=false;
        int r=0;
        System.out.println(list4);
        for(String time:list4){
            r++;
            System.out.println("Press "+r+" for "+list4.get(r-1)+" slot ");
        }
        int slot=0;
        while(!sucess4){
            try {
                System.out.print("\nEnter the Number = ");
                slot = input5.nextInt();
                if(slot==1||slot==2||slot==3||slot==4){
                    sucess4=true;
                }else{
                    System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

                }
            }catch (InputMismatchException e){
                input5.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

            }catch (IndexOutOfBoundsException ex){
                input5.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");


            }


        }
        Booking[m]+=","+list4.get(slot-1);
        list4.remove(slot-1);

    }
}
