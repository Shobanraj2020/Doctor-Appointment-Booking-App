package com.company;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Nutritionist {
    Scanner input2 = new Scanner(System.in);


    public void Balamurugan(String Booking[], List<String> list1,int k) {
        boolean sucess2=false;
        int i=0;
        for(String time:list1){
            i++;
            System.out.println("Press "+i+" for "+list1.get(i-1)+" slot ");
        }
        int slot=0;
        while(!sucess2){
            try {
                System.out.print("\nEnter the Number = ");
                slot = input2.nextInt();

                if((slot==1||slot==2||slot==3||slot==4)){
                    sucess2=true;
                }else{
                    System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

                }
            }catch (InputMismatchException e){
                input2.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

            }catch (IndexOutOfBoundsException ex){
                input2.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");


            }


        }



        Booking[k]+=","+list1.get(slot-1);
        list1.remove(slot-1);


    }



}
