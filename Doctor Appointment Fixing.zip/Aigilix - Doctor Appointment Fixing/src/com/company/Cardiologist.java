package com.company;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Cardiologist{
    Scanner input3= new Scanner(System.in);


        public void SankaraNarayanan(String Booking[], List<String> list2,int l){

            boolean sucess3=false;
            int j=0;
            System.out.println(list2);
            for(String time:list2){
                j++;
                System.out.println("Press "+j+" for "+list2.get(j-1)+" slot ");
            }
            int slot=0;
            while(!sucess3){
                try {
                    System.out.print("\nEnter the Number = ");
                    slot = input3.nextInt();
                    if(slot==1||slot==2||slot==3||slot==4){
                        sucess3=true;
                    }else{
                        System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

                    }
                }catch (InputMismatchException e){
                    input3.next();
                    System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

                }catch (IndexOutOfBoundsException ex){
                    input3.next();
                    System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");


                }


            }




            Booking[l]+=","+list2.get(slot-1);
            list2.remove(slot-1);

        }


}
