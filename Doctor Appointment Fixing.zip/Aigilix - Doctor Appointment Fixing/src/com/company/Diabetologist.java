package com.company;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Diabetologist {
    Scanner input4= new Scanner(System.in);
    public void VenuGopal(String Booking[], List<String> list3, int m){
        boolean sucess4=false;
        int k=0;
        System.out.println(list3);
        for(String time:list3){
            k++;
            System.out.println("Press "+k+" for "+list3.get(k-1)+" slot ");
        }
        int slot=0;
        while(!sucess4){
            try {
                System.out.print("\nEnter the Number = ");
                slot = input4.nextInt();
                if(slot==1||slot==2||slot==3||slot==4){
                    sucess4=true;
                }else{
                    System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

                }
            }catch (InputMismatchException e){
                input4.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");

            }catch (IndexOutOfBoundsException ex){
                input4.next();
                System.out.println("--Entered a invalid data--Please enter a valid SLOT to Proceed with the Registration");


            }


        }
        Booking[m]+=","+list3.get(slot-1);
        list3.remove(slot-1);


    }
}
