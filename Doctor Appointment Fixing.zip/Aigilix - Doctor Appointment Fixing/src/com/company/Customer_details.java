package com.company;

import java.util.Arrays;

public class Customer_details {
    public void details(long Mobile,String[] Booking_details){

        int count2=0;
        String Alldetail="";
        //System.out.println(Arrays.toString(Booking_details));
        String mobile_num=String.valueOf(Mobile);
        for(int i=0;i<Booking_details.length-1;i++){
            if(Booking_details[i]!=null){

                String find[]=Booking_details[i].split(",");
                //System.out.println(Arrays.toString(find));

                for(int j=0;j< find.length;j++){

                    if(mobile_num.equals(find[j])){
                        Alldetail=Booking_details[i];
                        count2++;
                        break;
                    }

                }
            }
            if(count2>0){
                break;
            }
        }
        if(count2==0){
            System.out.println("NO DETAILS FOR THIS PHONE NUMBER");
        }

if(count2>0) {
    String details[] = Alldetail.split(",");
    System.out.print("     ********* APPOINTMENT DETAILS *********");
    System.out.print("\n     Name of the patient = " + details[0]);
    System.out.print("\n     Age of the patient = " + details[1]);
    System.out.print("\n     Mobile Number = " + details[2]);
    System.out.print("\n     Speciality = " + details[3]);
    System.out.print("\n     Doctor's Name = " + details[4]);
    System.out.print("\n     Timing slot = " + details[5]);
}
        return;

    }
}
